package com.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URLEncoder;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class Command {
	private Socket client;
	/**
	 * �Ƿ���������
	 * @param context
	 * @return
	 */
	public static boolean isNetworkAvailable(Context context) { 
        ConnectivityManager connectivity = (ConnectivityManager) context 
                .getSystemService(Context.CONNECTIVITY_SERVICE); 
        if (connectivity != null) { 
            NetworkInfo info = connectivity.getActiveNetworkInfo(); 
            if (info != null && info.isConnected())  
            { 
                if (info.getState() == NetworkInfo.State.CONNECTED)  
                { 
                    return true; 
                } 
            } 
        } 
        return false; 
    }  
	
	
	public boolean start() {
		try {
			client = new Socket();
			// client.connect(new InetSocketAddress(Constants.SERVER_IP,
			// Constants.SERVER_PORT), 3000);
			client.connect(new InetSocketAddress("122.11.42.196", 80), 3000);
			//if (client.isConnected()) {
				
				//clientThread = new ClientThread(client);
				//clientThread.start();
				return true;
			//}
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		//return false;
	}
	/*
	 * ��ֹ�������  �ύ
	 */
	 private static long lastClickTime;
	    public static boolean isFastDoubleClick() {
	        long time = System.currentTimeMillis();
	        long timeD = time - lastClickTime;
	        if ( 0 < timeD && timeD < 1000) { 
	        	lastClickTime = time;
	            return true;   
	        }   
	        lastClickTime = time;   
	        return false;   
	    }
	    
	    public static String encoder(String value)
	    		throws UnsupportedEncodingException {
	    		// ת����
	    		String enUft = URLEncoder.encode(value, "GBK");
	    		java.net.URLDecoder urlDecoder = new java.net.URLDecoder();
	    		String str = urlDecoder.decode(enUft, "GBK");
	    		return str;
	    		}
	    
	    //������������  
	    public static void changeViewSize(ViewGroup viewGroup,int screenWidth,int screenHeight) {//����Activity����Layout,��Ļ��,��Ļ��  
	            int adjustFontSize = adjustFontSize(screenWidth,screenHeight);  
	            for(int i = 0; i<viewGroup.getChildCount(); i++ ){  
	                View v = viewGroup.getChildAt(i);  
	                if(v instanceof ViewGroup){  
	                    changeViewSize((ViewGroup)v,screenWidth,screenHeight);  
	                }else if(v instanceof Button){//��ť�Ӵ����һ��Ҫ����TextView���棬��ΪButtonҲ�̳���TextView  
	                    ( (Button)v ).setTextSize(adjustFontSize+2);  
	                }else if(v instanceof TextView){  
	                	/*
	                    if(v.getId()== R.id.title_msg){//��������  
	                        ( (TextView)v ).setTextSize(adjustFontSize+4);  
	                    }else{  
	                        ( (TextView)v ).setTextSize(adjustFontSize);  
	                    }  
	                    */
	                }  
	            }  
	        }  
	      
	      
	    //��ȡ�����С  
	    public static int adjustFontSize(int screenWidth, int screenHeight) {  
	            screenWidth=screenWidth>screenHeight?screenWidth:screenHeight;  
	            /** 
	             * 1. ����ͼ�� onsizechanged���ȡ��ͼ���ȣ�һ�������Ĭ�Ͽ�����320�����Լ���һ�����ű��� 
	                rate = (float) w/320   w��ʵ�ʿ��� 
	               2.Ȼ������������ߴ�ʱ paint.setTextSize((int)(8*rate));   8���ڷֱ��ʿ�Ϊ320 ����Ҫ���õ������С 
	                                      ʵ�������С = Ĭ�������С x  rate 
	             */  
	            int rate = (int)(5*(float) screenWidth/320); 
	            return rate<12?12:rate; 
	    }  
	    
	    public static int getScreenWidth(Context context) {
			WindowManager manager = (WindowManager) context
					.getSystemService(Context.WINDOW_SERVICE);
			Display display = manager.getDefaultDisplay();
			return display.getWidth();
		}

		public static int getScreenHeight(Context context) {
			WindowManager manager = (WindowManager) context
					.getSystemService(Context.WINDOW_SERVICE);
			Display display = manager.getDefaultDisplay();
			return display.getHeight();
		}

		public static float getScreenDensity(Context context) {
			try {
				DisplayMetrics dm = new DisplayMetrics();
				WindowManager manager = (WindowManager) context
						.getSystemService(Context.WINDOW_SERVICE);
				manager.getDefaultDisplay().getMetrics(dm);
				return dm.density;
			} catch (Exception ex) {

			}
			return 1.0f;
		}
		
		public static ViewGroup getRootView(Activity context)  
		   {  
		        return ((ViewGroup)context.findViewById(android.R.id.content));  
		    }  

}
