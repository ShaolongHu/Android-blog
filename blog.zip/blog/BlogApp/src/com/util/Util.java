package com.util;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



public class Util {

	private ArrayList<String> arrList = new ArrayList<String>();    
    private ArrayList<String> barrList = new ArrayList<String>();    
    private ArrayList<String> dataList = new ArrayList<String>();    
    private Conn Soap = new Conn();    
    
    public static Connection getConnection() {    
        Connection con = null;    
        try {    
                
        } catch (Exception e) {    
            //e.printStackTrace();     
        }    
        return con;    
    }    
    
    /**  
     * ��ѯ 
     * @return  
     */    
    public List<HashMap<String, String>> getAllInfo() {    
        List<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();    
        arrList.clear();    
        barrList.clear();    
        dataList.clear();    
        dataList = Soap.GetWebServre("GetAllArticle", arrList, barrList);    
    
        HashMap<String, String> tempHash = new HashMap<String, String>();    
        tempHash.put("ID", "���");    
        tempHash.put("UserName", "��");    
        tempHash.put("DeptID", "��");    
        list.add(tempHash);  
          
            
        for (int j = 0; j < dataList.size(); j+=3) {    
            HashMap<String, String> hashMap = new HashMap<String, String>();    
            hashMap.put("ID", dataList.get(j));    
            hashMap.put("UserName", dataList.get(j+1));    
            hashMap.put("DeptID", dataList.get(j+2));    
            list.add(hashMap);    
        }    
    
        return list;    
    }    
    
    /**  
     * ���� 
     *   
     * @return  
     */    
    public int   Add(String Question, String Answer) {    
        arrList.clear();    
        barrList.clear();    
        arrList.add("Question");    
        arrList.add("Answer");    
        barrList.add(Question);    
        barrList.add(Answer);    
        ArrayList<String> test = new ArrayList<String>();
        test=Soap.GetWebServre("Add", arrList, barrList); 
       if((test !=null )&&(!test.isEmpty())&&(test.size()>0))
       {
          return  1;
       }
       return 0;
      
    }  
    /**  
     *  ��������
     *   
     * @return  
     */   
    public int  AddMesssage(String TContext, String News_GID) {    
        arrList.clear();    
        barrList.clear();    
        arrList.add("TContext");    
        arrList.add("News_GID");    
        barrList.add(TContext);    
        barrList.add(News_GID);    
        ArrayList<String> test = new ArrayList<String>();
        test=Soap.GetWebServre("AddMesssage", arrList, barrList); 
       if((test !=null )&&(!test.isEmpty())&&(test.size()>0))
       {
          return  1;
       }
       return 0;
      
    }    
    /**  
     *  
     *   ��
     * @return  
     */   
    public int UpdateGoodCount(String GID) {    
        arrList.clear();    
        barrList.clear();    
        arrList.add("GID");      
        barrList.add(GID);    
        ArrayList<String> test = new ArrayList<String>();
        test=Soap.GetWebServre("UpdateGoodCount", arrList, barrList); 
       if((test !=null )&&(!test.isEmpty())&&(test.size()>0))
       {
          return  1;
       }
       return 0;
      
    }  
    
    /**  
     *  ������ѯ
     *   
     * @return  
     */   
    public int  AddPreventionInfo(String TContext,String IsPublic) {    
        arrList.clear();    
        barrList.clear();    
         
        arrList.add("TContext");    
        arrList.add("IsPublic");    
        barrList.add(TContext);    
        barrList.add(IsPublic);    
        ArrayList<String> test = new ArrayList<String>();
        test=Soap.GetWebServre("AddPreventionInfo", arrList, barrList); 
       if((test !=null )&&(!test.isEmpty())&&(test.size()>0))
       {
          return  1;
       }
       return 0;
      
    }    
    
    /**  
     *  ������ѯ
     *   
     * @return  
     */   
    public int  UpdateSurveyAnswerItem(String answerList) {    
        arrList.clear();    
        barrList.clear();    
         
        arrList.add("answerList");    
    
        barrList.add(answerList);    
        
        ArrayList<String> test = new ArrayList<String>();
        test=Soap.GetWebServre("UpdateSurveyAnswerItem", arrList, barrList); 
       if((test !=null )&&(!test.isEmpty())&&(test.size()>0))
       {
          return  1;
       }
       return 0;
      
    }    
    /**  
     * ɾ��  
     * @return  
     */    
    public void deleteCargoInfo(String Cno) {    
        arrList.clear();    
        barrList.clear();    
        arrList.add("Cno");    
        barrList.add(Cno);    
        Soap.GetWebServre("deleteCargoInfo", arrList, barrList);    
    }    
    public String  GetHello() {    
        dataList = Soap.GetWebServre("HelloWorld", arrList, barrList);       
        return dataList.toString();  
    }    
    public String  GetQuestion() {    
        dataList = Soap.GetWebServre("GetQuestion", arrList, barrList);       
        return dataList.toString();  
    }    
}    
