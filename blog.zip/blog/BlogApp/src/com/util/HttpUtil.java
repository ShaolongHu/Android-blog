package com.util;



import java.io.IOException;

import java.io.InputStream;

import java.net.HttpURLConnection;

import java.net.MalformedURLException;

import java.net.URL;

import org.apache.http.HttpResponse;

import org.apache.http.client.ClientProtocolException;

import org.apache.http.client.HttpClient;

import org.apache.http.client.methods.HttpGet;

import org.apache.http.client.methods.HttpPost;

import org.apache.http.impl.client.DefaultHttpClient;

import org.apache.http.util.EntityUtils;

public class HttpUtil {

	// ͨ��url���HttpGet����

	public static HttpGet getHttpGet(String url) {

		// ʵ����HttpGet

		HttpGet request = new HttpGet(url);

		return request;

	}

	// ͨ��URL���HttpPost����

	public static HttpPost getHttpPost(String url) {

		// ʵ����HttpPost

		HttpPost request = new HttpPost(url);

		return request;

	}

	// ͨ��HttpGet���HttpResponse����

	public static HttpResponse getHttpResponse(HttpGet request)

	throws ClientProtocolException, IOException {

		// ʵ����HttpResponse

		HttpResponse response = new DefaultHttpClient().execute(request);

		return response;

	}

	// ͨ��HttpPost���HttpResponse����

	public static HttpResponse getHttpResponse(HttpPost request)

	throws ClientProtocolException, IOException {

		// ʵ����HttpResponse

		HttpResponse response = new DefaultHttpClient().execute(request);

		return response;

	}

	// ͨ��url����post���󣬷���������

	public static String queryStringForPost(String url) {

		// ���HttpPostʵ��

		HttpPost request = HttpUtil.getHttpPost(url);

		String result = null;

		try {

			// ���HttpResponseʵ��

			HttpResponse response = HttpUtil.getHttpResponse(request);

			// �ж��Ƿ�����ɹ�

			// if(response.getStatusLine().getStatusCode() ==200){

			// ��÷��ؽ��

			result = EntityUtils.toString(response.getEntity());
		

			return result;

			// }

		} catch (ClientProtocolException e) {

			e.printStackTrace();

			result = "NetWork Exception";

			return result;

		} catch (IOException e) {

			e.printStackTrace();

			result = "NetWork Exception";

			return result;

		}

		// return null;

	}

	// ͨ��url����get���󣬷���������

	public static String queryStringForGet(String url) {

		// ���HttpGetʵ��

		HttpGet request = HttpUtil.getHttpGet(url);

		String result = null;

		try {

			// ���HttpResponseʵ��

			HttpResponse response = HttpUtil.getHttpResponse(request);

			// �ж��Ƿ�����ɹ�

			// if(response.getStatusLine().getStatusCode()==200){

			// ��÷��ؽ��

			result = EntityUtils.toString(response.getEntity());

			return result;

			// }

		} catch (ClientProtocolException e) {

			e.printStackTrace();

			result = "NetWork Exception";

			return result;

		} catch (IOException e) {

			e.printStackTrace();

			result = "NetWork Exception";

			return result;

		}

		// return null;

	}

	// ͨ��HttpPost����Post���󣬷���������

	public static String queryStringForPost(HttpPost request) {

		String result = null;

		try {

			// ���HttpResponseʵ��

			HttpResponse response = HttpUtil.getHttpResponse(request);

			// �ж��Ƿ�����ɹ�

			// if(response.getStatusLine().getStatusCode()==200){

			// ���������

			result = EntityUtils.toString(response.getEntity());

			return result;

			// }

		} catch (ClientProtocolException e) {

			e.printStackTrace();

			result = "NetWork Exception";

			return result;

		} catch (IOException e) {

			e.printStackTrace();

			result = "NetWork Exception";

			return result;

		}

		// return null;

	}

	// ͨ��HttpGet����Get���󣬷���������

	public static String queryStringForGet(HttpGet request) {

		String result = null;

		try {

			// ���HttpResponseʵ��

			HttpResponse response = HttpUtil.getHttpResponse(request);

			// �ж��Ƿ�����ɹ�

			// if(response.getStatusLine().getStatusCode()==200){

			// ���������

			result = EntityUtils.toString(response.getEntity());

			return result;

			// }

		} catch (ClientProtocolException e) {

			e.printStackTrace();

			result = "NetWork Exception";

			return result;

		} catch (IOException e) {

			e.printStackTrace();

			result = "NetWork Exception";

			return result;

		}

		// return null;

	}

	public static InputStream GetInputStreamFromURL(String urlstr) {

		HttpURLConnection connection;

		URL url;

		InputStream stream = null;

		try {

			url = new URL(urlstr);

			connection = (HttpURLConnection) url.openConnection();

			connection.connect();

			stream = connection.getInputStream();
			
			
			//stream.close();
		} catch (MalformedURLException e) {
			

			e.printStackTrace();

		} catch (IOException e1) {
			

			e1.printStackTrace();

		}

		return stream;

	}

}
