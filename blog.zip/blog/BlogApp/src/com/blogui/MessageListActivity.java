package com.blogui;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.blogui.Messagelist.OnRefreshListener;
import com.config.Constants;
import com.util.HttpUtil;
import com.util.PullBookParser;

/*
 * 作者:洪生鹏
 * 网站：http://www.hongshengpeng.com
 * 日期：2013-12-22
 * 请保留相关信息，不做商业用途
 * 
 * 
 */


public class MessageListActivity extends AbstructCommonActivity {

	//

	// private static String url =
	// "http://www.hongshengpeng.com/tel/testtel.ashx?id=1";

	//private  String url = "http://www.hongshengpeng.com/android/articlelist.ashx";
	private String url = Constants.newsURL +"?classid=67&pageSize=1";

	private static final String TAG = "XML";

	private BookParser parser;
	private List<Book> books;
	ListView viewBookList;

	BookItemAdapter adapterNew;

	// ViewGroup listFolder;

	LoadStateView loadStateView;
	TextView tv = null;
	//
	private static final int INTERNET_FAILURE = -1;
	private static final int LOAD_SUCCESS = 1;
	private static final int LOAD_MORE_SUCCESS = 3;
	private static final int NO_MORE_INFO = 4;
	private static final int LOAD_NEW_INFO = 5;

	private Messagelist pullListView;
	private ProgressBar moreProgressBar;

	private List<String> dataList;
	String typeGID ="";
	// private ArrayAdapter<String> adapter;

	private SimpleAdapter adapter;
	List<Map<String, Object>> list;

	Button back = null,hot =null;
	int flag = 2;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.message_list);

		pullListView = (Messagelist) this.findViewById(R.id.pullListView);
		
		pullListView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {

				TextView c = (TextView) arg1.findViewById(R.id.sItemTitle);
				TextView vtURL = (TextView) arg1.findViewById(R.id.sItemInfo);
				// ImageView img= (ImageView) arg1.findViewById(R.id.sItemIcon);
				String book_name = c.getText().toString();
				String book_url = vtURL.getText().toString();
				Intent intent = new Intent();
				intent.setClass(MessageListActivity.this, ArticleDetail.class);
				intent.putExtra("book_name", book_name);
				intent.putExtra("book_url", book_url);
				intent.putExtra("typeGID",typeGID);
				// intent.putExtra("img", imgView);
				// intent.putExtra("data", data);
				// intent.putCharSequenceArrayListExtra(name, value)("efood",
				// data);
				startActivity(intent);
				// Toast.makeText(getApplicationContext(),
				// "地址名称:"+book_url, Toast.LENGTH_SHORT).show();
				//
			}
		});
		dataList = new ArrayList<String>();
		list = new ArrayList<Map<String, Object>>();
		//if (Commond.isNetworkAvailable(getApplicationContext())) 
		//{
			try {
               // url +="&type="+typeGID;
				InputStream is = HttpUtil.GetInputStreamFromURL(url);
				parser = new PullBookParser(); //
				books = parser.parse(is); //
				for (int i = 0; i < books.size(); i++) {
					dataList.add(books.get(i).getName());
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("sItemTitle", books.get(i).getName());
					map.put("sItemInfo", books.get(i).getGID());
					list.add(map);
				}
				Log.v(TAG, url + flag);
			} catch (Exception e) {
				Log.e(TAG, e.getMessage());
			}
			// adapter = new ArrayAdapter<String>(this,
			// android.R.layout.simple_list_item_1, dataList);
			adapter = new SimpleAdapter(this, list, R.layout.book_item_adapter,
					new String[] { "sItemTitle", "sItemInfo" }, new int[] {
							R.id.sItemTitle, R.id.sItemInfo });

			pullListView.setAdapter(adapter);
		//} else

	//	{
		//	Toast.makeText(getApplicationContext(), "当前网络不可用，请检查！",
		//			Toast.LENGTH_SHORT).show();
		//}
		LayoutInflater inflater = LayoutInflater.from(this);
		View view = inflater.inflate(R.layout.list_footview, null);
		RelativeLayout footerView = (RelativeLayout) view
				.findViewById(R.id.list_footview);
		moreProgressBar = (ProgressBar) view.findViewById(R.id.footer_progress);
		pullListView.addFooterView(footerView);

		pullListView.setonRefreshListener(new OnRefreshListener() {

			@Override
			public void onRefresh() {
				// new Thread(new Runnable() {

				// @Override
				// public void run() {
				try {
					Thread.sleep(1000);
					// dataList.clear();
					list.clear();
					try {
              	//	url = "?id=1&type="+typeGID;
						InputStream is = HttpUtil.GetInputStreamFromURL(url);

						parser = new PullBookParser();
						books = parser.parse(is);
						for (int i = 0; i < books.size(); i++) {
							Map<String, Object> map = new HashMap<String, Object>();
							// dataList.add(books.get(i).getName());
							map.put("sItemTitle", books.get(i).getName());
							map.put("sItemInfo", books.get(i).getGID());
							list.add(map);

						}

						Log.v(TAG, url);

					} catch (Exception e) {
						Log.e(TAG, e.getMessage());
					}
					myHandler.sendEmptyMessage(LOAD_NEW_INFO);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			// }).start();
			// }
		});

		footerView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				moreProgressBar.setVisibility(View.VISIBLE);

				new Thread(new Runnable() {

					@Override
					public void run() {
						try {

							Thread.sleep(100);

							try {
								url = url;
								InputStream is = HttpUtil
										.GetInputStreamFromURL(url);
								parser = new PullBookParser();
								books = parser.parse(is);
								for (int i = 0; i < books.size(); i++) {
									Map<String, Object> map = new HashMap<String, Object>();
									// dataList.add(books.get(i).getName());
									map.put("sItemTitle", books.get(i)
											.getName());
									map.put("sItemInfo", books.get(i).getGID());
									list.add(map);

								}
								flag++;

								Log.e(TAG, url + flag);

							} catch (Exception e) {
								Log.e(TAG, e.getMessage());
							}
							// }
							myHandler.sendEmptyMessage(LOAD_MORE_SUCCESS);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}).start();
			}
		});

	}

	private Handler myHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case LOAD_MORE_SUCCESS:
				moreProgressBar.setVisibility(View.GONE);
				adapter.notifyDataSetChanged();
				pullListView.setSelectionfoot();
				break;
			case LOAD_NEW_INFO:
				adapter.notifyDataSetChanged();
				pullListView.onRefreshComplete();
				break;
			default:
				break;
			}
		}
	};


}
