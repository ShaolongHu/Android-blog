package com.blogui;

/*
 * ����:������
 * ��վ��http://www.hongshengpeng.com
 * ���ڣ�2013-12-22
 * �뱣�������Ϣ��������ҵ��;
 * 
 * 
 */

public class Book {
	private int id;
	private String name;
	private float price;
	private String gid;
	
	private String web_url;
	
	private String content;
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	public String getGID() {
		return gid;
	}

	public void setGID(String gid) {
		this.gid = gid;
	}
	
	public String getWebURL() {
		return web_url;
	}
	public void setWebURL(String web_url) {
		this.web_url = web_url;
	}
	
	//��������
	public String getContent() {
		return content;
	}
	public void setContent(String content)
	{
		this.content = content;
	}
	@Override
	public String toString() {
		return "id:" + id + ", name:" + name + ", price:" + price;
	}
}

