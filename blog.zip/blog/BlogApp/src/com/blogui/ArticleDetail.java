package com.blogui;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Html;
import android.text.Html.ImageGetter;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;



import com.config.Constants;
import com.util.ImageFileCache;
import com.util.ImageGetFromHttp;
import com.util.ImageLoadingDialog;
import com.util.MyImageGetter;
import com.util.MyTagHandler;
import com.util.SDUNtil;
import com.util.Util;
import com.zdp.aseo.content.AseoZdpAseo;

/*
 * ����:������
 * ��վ��http://www.hongshengpeng.com
 * ���ڣ�2013-12-22
 * �뱣�������Ϣ��������ҵ��;
 * 
 * 
 */


public class ArticleDetail extends Activity {
	private EditText tv;
	private TextView v;
	
	private static final int OK = 1;
	private static final int ERROR = 0;
	private BookParser parser;
	private List<Book> books;
	Spanned text=null;
	private ProgressDialog pd =null;
	Button back = null;
	Button submit = null ,reback_btn =null;
	String url="";
	String typeGID ="";
	private Util dbUtil;
	EditText con ;
	String gid="";
	
	String title="";
	
	RadioButton rb =null;
	RadioButton next = null,back_return =null,good = null;
	
    private Button confirmButton;
    private Button cancleButton;
    private PopupWindow popupWindow;
    private PopupWindow popupWindowshare;
    private View popupWindowView;
    private EditText leaveword ;
    
    private TextView titleTv,fontSmall,fontMiddle,fontLarge;
    private CheckBox  fontset ;
    
    ImageLoadingDialog dialog;
    //����
    private Button weixinhaoyou,weixinpengyou,xinlang,youjian,cancleback;
    
    
    SharedPreferences f;  
	int fontSize ; 
	Editor editor;
	
	
	@Override
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.article_detail);
		init();
		dbUtil = new Util();
		
		v = (TextView) findViewById(R.id.details);
		
		
		v.setMovementMethod(ScrollingMovementMethod.getInstance());
		titleTv  =(TextView) findViewById(R.id.txt_doc_query);
		f = this.getSharedPreferences("font_size", MODE_PRIVATE);  
		fontSize = f.getInt("fontSize", 14); 
		editor = f.edit();   
		if( fontSize !=0)
		{
		 v.setTextSize(fontSize);
		 fontSmall.setBackgroundColor(Color.RED);
		}
		//pd= ProgressDialog.show(ArticleDetail.this, "���Ե�...", "������...");
		Bundle extras = getIntent().getExtras(); 
		AseoZdpAseo.initType(this, AseoZdpAseo.SCREEN_TYPE);
		dialog = new ImageLoadingDialog(this);
		dialog.setCanceledOnTouchOutside(false);
		dialog.show();
		
		if(extras!=null)
		{
			gid= extras.getString("book_url");
			typeGID= extras.getString("typeGID");
			
			//���±���
			title = extras.getString("book_name");
			titleTv.setText(title);
		}	
		url =Constants.newsDetailURL+"?id="+gid;
	 //Toast.makeText(ArticleDetail.this, gid,Toast.LENGTH_SHORT).show();
	 // if(Command.isNetworkAvailable(getApplicationContext()))
	 // { 
		createThread();
		/*
		if(SDUNtil.SDCardState())
		{
			createThread();
		}
		else
		{
			Toast.makeText(ArticleDetail.this, "��ǰ�ڴ濨�����ã�ͼƬ���ܲ����ã�",Toast.LENGTH_SHORT).show();
			dialog.dismiss();
		}
		*/
	 // }
	 // else 
		/*
	  {
		Toast.makeText(getApplicationContext(), "��ǰ���粻���ã����飡", Toast.LENGTH_SHORT).show(); 
		dialog.dismiss();
		
	  }
	  */
	  
	 
		
	}
	
	

	
	private void showLoading(boolean bShow) {

		// mLoading.setVisibility(bShow ? View.VISIBLE : View.GONE);
	}

	public void createThread() {
		/***
		 * ����UI
		 */

		final Handler handler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				switch (msg.what) {
				case OK:
					try {
						Thread.sleep(100);
						
						v.setText(text);
			
						v.setMovementMethod(LinkMovementMethod.getInstance());
						
						
						//pd.dismiss();
						
						dialog.dismiss();
						// showLoading(false); //�ü��ؿ�����ʾ
						// gridview.setAdapter(ia); //������
					} catch (Exception e) {
						
						e.printStackTrace();
						dialog.dismiss();

					}
					break;
				default:
					dialog.dismiss();
					break;
				}

			}

		};

		final Message message = new Message();

		new Thread(new Runnable() {
			@Override
			public void run() {

				try {
					// ����ͼƬ����
					// showLoading(true);
					
				
					
					//String url = "http://10.0.2.2:5785/WebSite2/Android/details.ashx";
					//	InputStream is = HttpUtil.GetInputStreamFromURL(url);
					//	parser = new PullBookParser(); //
					//	books = parser.parse(is); //
					 

						//text = Html.fromHtml(GetHtml(url), imgGetter,
									//null);
			
					text = Html.fromHtml(GetHtml(url), new MyImageGetter(ArticleDetail.this, v), new MyTagHandler(ArticleDetail.this));
						//  text = Html.fromHtml(GetHtml(url));
					
					
					message.what = OK;
					handler.sendMessage(message); // ����֪ͨ
				} catch (Exception e) {
					e.printStackTrace();
					message.what = ERROR;
					handler.sendMessage(message);
				}
			}
		}).start();
	}

	ImageGetter imgGetter = new Html.ImageGetter() {

		@Override
		public Drawable getDrawable(String source) {

			Drawable d = null;
		  Bitmap defaultBit = null;
			try {
				
				URL aryURI = new URL(source);
				/* ������ */
				URLConnection conn = aryURI.openConnection();
				conn.connect();
				/* ת��Ϊ InputStream */
				InputStream is = conn.getInputStream();
				
				//-------------------
				
				//-------------------
				/* ��InputStreamת��ΪBitmap */
				// Bitmap bm = BitmapFactory.decodeStream(is);
				/* �ر�InputStream */
				/* ����ͼƬ */
				
				 BitmapFactory.Options options=new BitmapFactory.Options();
			     options.inJustDecodeBounds = false;
			     if( options.outWidth >300)
			     {
			        options.inSampleSize = 10;  //100 200 10 20
			     }
			     Bitmap btp= null;
			  
			     try
			     {
			    defaultBit = BitmapFactory.decodeResource(ArticleDetail.this.getResources(),R.drawable.ic_launcher);
			       btp =BitmapFactory.decodeStream(is,null,options);
			      // btp= getBitmap(source);
			       Log.v("", "no data");
			       
			      d = new BitmapDrawable(btp); 
			     }
			     catch(OutOfMemoryError ooe)
			     {
			    	 ooe.printStackTrace();
			     }
			     if (btp == null) {
			    	    // ���ʵ����ʧ�� ����Ĭ�ϵ�Bitmap����
			    	 //   return new BitmapDrawable(defaultBit);
			     }
			    //d = Drawable.createFromStream(is, "111");
				is.close();
			} catch (IOException e) {
				//e.printStackTrace();
				Drawable tempD;
				tempD = new BitmapDrawable(defaultBit);
				tempD.setBounds(0, 0, tempD.getIntrinsicWidth(), tempD.getIntrinsicHeight());
				Log.v("", "exception");
				return tempD;
			}
			//d.setBounds(1, 1, 45, 45);
			int width=d.getIntrinsicWidth();
			int height = d.getIntrinsicHeight();
			if(width>300)
			{
				width =300;
			}
			if(height >300)
			{
				height = height/3;
			}
			 d.setBounds(0, 0, width, d.getIntrinsicHeight());
			return d;

		}
	};
	
	public static byte[] readStream(InputStream inputStream) throws Exception {
		byte[] buffer = new byte[1024];
		int len = -1;
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();


		while ((len = inputStream.read(buffer)) != -1) {
		byteArrayOutputStream.write(buffer, 0, len);
		}


		inputStream.close();
		byteArrayOutputStream.close();
		return byteArrayOutputStream.toByteArray();
		}


		public static String GetHtml(String urlpath) throws Exception {
		URL url = new URL(urlpath);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setConnectTimeout(6 * 1000);
		conn.setRequestMethod("GET");


		if (conn.getResponseCode() == 200) {
		InputStream inputStream = conn.getInputStream();
		byte[] data = readStream(inputStream);
		String html = new String(data);
		return html;
		}
		return "<span>no data</span>";
		}
	
		/*
		public boolean OnKeyDown(int keyCode,KeyEvent event){   
	        if (keyCode==KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {   
	            Intent intent=new Intent();   
	            intent.setClass(ArticleDetail.this, MessageListviewActivity.class);   
	            startActivity(intent);   
	            ArticleDetail.this.finish();   
	        }      
	        return false;   
	     }
	     */  
		/*** ���һ��ͼƬ,�������ļ�����,���������ȡ ***/
		public Bitmap getBitmap(String url) {
		    // ���ڴ滺���л�ȡͼƬ
		
			ImageFileCache fileCache = null;
			
	
		    	Bitmap  result = fileCache.getImage(url);
		        if (result == null) {
		            // �������ȡ
		            result = ImageGetFromHttp.downloadBitmap(url);
		            if (result != null) {
		                fileCache.saveBitmap(result, url);
		              
		            }
		        } 
		
		    return result;
		}
		 private void init(){
	    	  rb=(RadioButton) findViewById(R.id.main_tab_discussion);
	    	  rb.setOnClickListener(new ButtonOnClickListener());
	    	  
	    	  
	    	  next=(RadioButton) findViewById(R.id.next);
	    	  next.setOnClickListener(new ButtonOnClickListener());
	    	  
	    	  back_return=(RadioButton) findViewById(R.id.main_tab_return);
	    	  back_return.setOnClickListener(new ButtonOnClickListener());
	    	  
	    	  
	    	   
	    	  
	    	  reback_btn=(Button) findViewById(R.id.reback_btn);
	    	  reback_btn.setOnClickListener(new ButtonOnClickListener());
	    	  
	    	  
	    	  good=(RadioButton) findViewById(R.id.main_tab_good);
	    	  good.setOnClickListener(new ButtonOnClickListener());
	    	  
	    	  
	    	  fontSmall =(TextView) findViewById(R.id.small);
	    	  fontSmall.setOnClickListener(new ButtonOnClickListener());
	    	  
	    	  
	    	  fontMiddle =(TextView) findViewById(R.id.middle);
	    	  fontMiddle.setOnClickListener(new ButtonOnClickListener());
	    	  
	    	  
	    	  fontLarge =(TextView) findViewById(R.id.large);
	    	  fontLarge.setOnClickListener(new ButtonOnClickListener());
	    }

		

			
		private class ButtonOnClickListener implements OnClickListener {
			@Override
			public void onClick(View vid) {
				
				switch (vid.getId()) {
				case R.id.reback_btn:
					Intent homeIntent = new Intent();
					homeIntent.setClass(ArticleDetail.this, HomePage.class);

					startActivity(homeIntent);
					ArticleDetail.this.finish();
					 break;
				case R.id.small:
					 editor.putInt("fontSize", 14);  
					 editor.commit();  
					 v.setTextSize(14);
                     break;
				case R.id.middle:
					  editor.putInt("fontSize", 16);  
					  editor.commit();  
					 v.setTextSize(16);
                   break;
				case R.id.large:
					  editor.putInt("fontSize", 18);  
					  editor.commit();  
					  v.setTextSize(18);
                   break;
                   
				case R.id.main_tab_return:
					 /*
					  Intent intent = new Intent(); 
					  intent.setClass(ArticleDetail.this, HomePage.class);
					  startActivity(intent);
					  ArticleDetail.this.finish();
					  */
					    Intent upIntent = new Intent();
					    upIntent.setClass(ArticleDetail.this, ArticleDetail.class);
					    upIntent.putExtra("book_name", "");
					    upIntent.putExtra("book_url",String.valueOf(Integer.parseInt(gid) -1));
					    upIntent.putExtra("typeGID",typeGID);
						startActivity(upIntent);
				     break;
				case R.id.main_tab_good: //��
				    String GID = gid;  // ���envelope.dotNet = true �����˳�򣬲�������Ҫ�ͷ�����ͬ��
					if(dbUtil.UpdateGoodCount(GID)>0)
				        {
				    	  Toast.makeText(ArticleDetail.this, "�ύ�ɹ�����л���Ĳ��룡",Toast.LENGTH_SHORT).show();
				        } 
				     else
				        {
				    	 Toast.makeText(ArticleDetail.this, "�ύʧ�ܣ������Ƿ�����æ�����Ժ����ԣ�",Toast.LENGTH_SHORT).show();
				        }
				     break;
				case R.id.next: //����
			         //
					
					Intent nextIntent = new Intent();
					nextIntent.setClass(ArticleDetail.this, ArticleDetail.class);
					nextIntent.putExtra("book_name", "");
					nextIntent.putExtra("book_url",String.valueOf(Integer.parseInt(gid) +1));
					nextIntent.putExtra("typeGID",typeGID);
					// intent.putExtra("img", imgView);
					// intent.putExtra("data", data);
					// intent.putCharSequenceArrayListExtra(name, value)("efood",
					// data);
					startActivity(nextIntent);
					break;
				case R.id.main_tab_discussion: //����
					LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
					popupWindowView = inflater.inflate(R.layout.popupwindow, null);
					popupWindow = new PopupWindow(popupWindowView,LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT,true);
					popupWindow.setBackgroundDrawable(new BitmapDrawable());
					//����PopupWindow�ĵ�������ʧЧ��
					popupWindow.setAnimationStyle(R.style.popupAnimation);
					confirmButton = (Button) popupWindowView.findViewById(R.id.confirmButton);
					confirmButton.setOnClickListener(new ButtonOnClickListener());
					cancleButton = (Button) popupWindowView.findViewById(R.id.cancleButton);
					cancleButton.setOnClickListener(new ButtonOnClickListener());
					
					leaveword =(EditText)popupWindowView.findViewById(R.id.leaveword);  
					popupWindow.showAtLocation(confirmButton, Gravity.CENTER, 0, 0);
					break;
				case R.id.confirmButton:
				
					//mEtPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());  
					//mEtPassword.postInvalidate(); 
					leaveword =(EditText)popupWindowView.findViewById(R.id.leaveword);  
					if(leaveword !=null)
					{
					String lw =leaveword.getText().toString();
					//String lw ="dddd";
					if(lw ==null || lw.equals(""))
					{   
						Log.v("null", "lw is empty");
						Toast.makeText(ArticleDetail.this, "���۲���Ϊ�գ�",Toast.LENGTH_SHORT).show();
				    	return;
					}
					else
					{
				      int flag = dbUtil.AddMesssage(lw,gid);
				      if(flag >0)
				        {
				    	  Toast.makeText(ArticleDetail.this, "���۳ɹ�����������У�",Toast.LENGTH_SHORT).show();
				    	  popupWindow.dismiss();
				        }
				     else
				        {
				    	 Toast.makeText(ArticleDetail.this, "�����ύʧ�ܣ������Ƿ�����æ�����Ժ����ԣ�",Toast.LENGTH_SHORT).show();
				        }
					}
					}
					break;
				case R.id.cancleButton:
					popupWindow.dismiss();
					break;

				default:
					break;
				}
			}
		}
		
		@Override
		public void onConfigurationChanged(Configuration newConfig) {
			try {
				super.onConfigurationChanged(newConfig);
				if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
					// land
					// setContentView(R.layout.url_connection_image);
				} else if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
					// port
				}
			} catch (Exception ex) {
				Log.v("swith", "�л�ʧ��");
			}
		}


}