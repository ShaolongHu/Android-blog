package com.blogui;





import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.util.DownloadService;

public class More  extends Activity{
	TextView aboutus,advise,help,mess,info,infonew;
	RadioButton home,catagory = null,rbsearch =null,more = null;
	Button toback =null,btnCancel=null;
	
	private DownloadService.DownloadBinder binder;  
    private TextView text;
    private ProgressBar progress;
    private Context mContext = this;
    
   
	   @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.more);
		

		
		init();
		
		
        text = (TextView) findViewById(R.id.text); 
        btnCancel =(Button) findViewById(R.id.btnCancel);
        progress = (ProgressBar)findViewById(R.id.pbProgress);
        
        Intent intent = new Intent(this, DownloadService.class);  
        startService(intent);   //����ȵ���startService,���ڶ������󶨶������unbindService������Բ��ᱻ����   
        bindService(intent, conn, Context.BIND_AUTO_CREATE); 
        
	
	}
	   
	   private void init(){
		   /*
		    aboutus = (TextView)findViewById(R.id.aboutus);
		    aboutus.setOnClickListener(new ButtonOnClickListener());
		    
			advise= (TextView)findViewById(R.id.advise);
			advise.setOnClickListener(new ButtonOnClickListener());
			
			help= (TextView)findViewById(R.id.help);
			help.setOnClickListener(new ButtonOnClickListener());
			
			mess= (TextView)findViewById(R.id.banben);
			mess.setOnClickListener(new ButtonOnClickListener()); 
			
			toback = (Button)findViewById(R.id.toback);
			toback.setOnClickListener(new ButtonOnClickListener()); 
			
			home=(RadioButton) findViewById(R.id.main_tab_home);
		  	  home.setOnClickListener(new ButtonOnClickListener());
		  	  
		  	  
		  	  rbsearch=(RadioButton) findViewById(R.id.main_tab_search);
		      rbsearch.setOnClickListener(new ButtonOnClickListener());
		  	  
		  	  catagory=(RadioButton) findViewById(R.id.main_tab_catagory);
		  	  catagory.setOnClickListener(new ButtonOnClickListener());
		  	  
		  	  more=(RadioButton) findViewById(R.id.main_tab_more);
		  	  more.setOnClickListener(new ButtonOnClickListener());
		  	  
		  	info=(TextView) findViewById(R.id.info);
		  	info.setOnClickListener(new ButtonOnClickListener());
		  	
		  	infonew=(TextView) findViewById(R.id.infonew);
		  	infonew.setOnClickListener(new ButtonOnClickListener());
		  	*/
	    }
	  	private class ButtonOnClickListener implements OnClickListener {
	  		@Override
	  		public void onClick(View v) {
	  			Intent intent = new Intent();
	  			switch (v.getId()) {
	  			/*
	  			case R.id.aboutus:  //��������
	  				
					intent.setClass(more.this, otherInfos.class);
					intent.putExtra("book_name", "��������");
					intent.putExtra("book_url", "02096a3e-f708-4141-a699-bb4e8e557e96");

					startActivity(intent);
	  			     break;
	  	       case R.id.advise: 
	  	    	    intent.setClass(more.this, survey.class);
				    intent.putExtra("typeTitle", "���ߵ���");
			
		    	    startActivity(intent);
	  			 	break;
	  			case R.id.help: 
	  				 intent.setClass(more.this, otherInfos.class);
				     intent.putExtra("book_name", "ʹ�ð���");
					 intent.putExtra("book_url", "cf17df02-dab7-45a0-abbf-0895e6c7a917");
					 startActivity(intent);
	  			     break;
	  			case R.id.banben: 
	  				// Toast.makeText(more.this, "��ǰ�汾Ϊ1.0",Toast.LENGTH_SHORT).show();
	  				final ProgressDialog pd = new ProgressDialog(mContext);
	    			pd.setMessage("���ڼ���Ƿ����µİ汾...");
	    			pd.setCancelable(false);
	    			pd.show();
	    			
	    			new Thread()
	    			{
	    				public void run()
	    				{
	    					if(!binder.isCancelled()) 
	    					{
	    						binder.start();
	    						hand.sendEmptyMessage(3);
	    			    		return;
	    					}
	    					
	    	    			if(binder.isNewVersion() == 0)
	    	    			{
	    	    				hand.sendEmptyMessage(0);
	    				    }
	    			    	else
	    			    	{
	    			    		hand.sendEmptyMessage(1);
	    			    	}
	    	    			
	    	    			pd.dismiss();
	    				}
	    			}.start();
	  				 break;
	  			case R.id.toback:
	  				intent.setClass(more.this, home.class);
		    	    startActivity(intent);
	  				break;
	  		   */
	  			default:
	  				break;
	  			}
	  		}
	      }
	  	
	  
	  	
	    private Handler handler = new Handler()
	    {  
	        public void handleMessage(android.os.Message msg)
	        {  
	            text.setText("downloading..." + msg.arg1 + "%");
	            progress.setProgress(msg.arg1);
	        };  
	    };  

	    private ServiceConnection conn = new ServiceConnection() 
	    {
	        @Override  
	        public void onServiceConnected(ComponentName name, IBinder service) 
	        {
	        	binder = (DownloadService.DownloadBinder)service;
	        }  
	  
	        @Override  
	        public void onServiceDisconnected(ComponentName name) { }
	    };  
	    
	    @Override  
	    protected void onDestroy() 
	    {  
	        super.onDestroy();  
	        if (null != binder)
	        {  
	            unbindService(conn);              
	        }
	    }
	    
	    public void cancel(View view)
	    {
	    	if(null != binder && !binder.isCancelled())
	    	{
	    		binder.cancel();
	    	}
	    }
	  
	    
	    private void listenProgress() 
	    {  
	        new Thread()
	        {  
	            public void run()
	            {  
	                while (binder.getProgress() <= 100) 
	                {  
	                    int progressload = binder.getProgress();  
	                    Message msg = handler.obtainMessage();  
	                    msg.arg1 = progressload;  
	                    handler.sendMessage(msg);  
	                    
	                    if (progressload == 100)
	                    {  
	                       //
	                        progress.setVisibility(View.GONE);
	        				btnCancel.setVisibility(View.GONE);
	        			    break;  
	                    }  
	                    
	                    try 
	                    {  
	                        Thread.sleep(200);  
	                    }
	                    catch (InterruptedException e) 
	                    {  
	                        e.printStackTrace();  
	                    }  
	                }  
	            };  
	        }.start();  
	    }  

	   

	  
	    protected final Handler hand = new Handler()
		{
			public void handleMessage(Message msg)
			{
				super.handleMessage(msg);
				
				switch(msg.what)
				{
					case 0:
						String mgs = binder.getVersionInfo().get(DownloadService.versionInfoField.description.toString());
						
						new AlertDialog.Builder(mContext).setTitle("�����µİ汾�ɸ���")
		        		.setMessage(mgs)
		        		.setPositiveButton("��������", new DialogInterface.OnClickListener() 
		        		{
		        			public void onClick(DialogInterface dialog, int which) 
		        			{   
		        				
		        				binder.start();
		        				listenProgress();
		        				
		        				progress.setVisibility(View.VISIBLE);
		        				btnCancel.setVisibility(View.VISIBLE);
		        				/*
		        				 Intent intent = new Intent();
		                         intent.setClass(more.this, appdownload.class);
		        			     startActivity(intent);
		        			     */
		        			}
		        		})
		        		.setNegativeButton("�´���˵",null).create().show();
						break;
					case 1:
			    		Toast.makeText(mContext, "��ǰ�Ѿ������°汾��", Toast.LENGTH_SHORT).show();
			    		break;
					case 2:
			    		Toast.makeText(mContext, "���°汾�������أ�", Toast.LENGTH_SHORT).show();
			    		break;
						
				};
			}
		};
	
        

		


	
	public void exit_settings(View v) {                           //�˳�  α���Ի��򡱣���ʵ��һ��activity
		//Intent intent = new Intent (More.this,ExitFromSettings.class);			
		//startActivity(intent);	
		/*
		final ProgressDialog pd = new ProgressDialog(mContext);
		pd.setMessage("���ڼ���Ƿ����µİ汾...");
		pd.setCancelable(false);
		pd.show();
		
		new Thread()
		{
			public void run()
			{
				if(!binder.isCancelled()) 
				{
					binder.start();
					hand.sendEmptyMessage(3);
		    		return;
				}
				
    			if(binder.isNewVersion() == 0)
    			{
    				hand.sendEmptyMessage(0);
			    }
		    	else
		    	{
		    		hand.sendEmptyMessage(1);
		    	}
    			
    			pd.dismiss();
			}
		}.start();
		*/
	 }

}
