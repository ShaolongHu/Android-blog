package com.blogui;



import com.zdp.aseo.content.AseoZdpAseo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class Welcome extends Activity {
  
   ImageView mSplashItem_iv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.welcome);
		initView();
	}

	protected void initView() {

		// TODO Auto-generated method stub

		mSplashItem_iv = (ImageView) findViewById(R.id.splash_loading_item);
		AseoZdpAseo.initType(this, AseoZdpAseo.INSERT_TYPE);
		Animation translate = AnimationUtils.loadAnimation(this,
	
		R.anim.splash_loading);

		translate.setAnimationListener(new AnimationListener() {

		 

		@Override

		public void onAnimationStart(Animation animation) {

		// TODO Auto-generated method stub

		}

		 

		@Override

		public void onAnimationRepeat(Animation animation) {

		// TODO Auto-generated method stub

		}

		 

		@Override

		public void onAnimationEnd(Animation animation) {

		Intent intent = new Intent();

		intent.setClass(Welcome.this, HomePage.class);

		startActivity(intent);

		//openActivity(Login.class);

		overridePendingTransition(R.anim.push_left_in,

		R.anim.push_left_out);

		Welcome.this.finish();

		}

		});

		mSplashItem_iv.setAnimation(translate);

		}
}
