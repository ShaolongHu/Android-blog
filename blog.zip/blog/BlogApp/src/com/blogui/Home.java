package com.blogui;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.config.Constants;
import com.util.HttpUtil;
import com.util.PullBookParser;
import com.zdp.aseo.content.AseoZdpAseo;

/*
 * 作者:洪生鹏
 * 网站：http://www.hongshengpeng.com
 * 日期：2013-12-22
 * 请保留相关信息，不做商业用途
 * 
 * 
 */

public class Home extends Activity {

	/** Called when the activity is first created. */

	Button btn1, life,xinli,yike,youmo, btn;

	Notification n;

	NotificationManager nm;

	String tag = "Welcome";
	ListView ls;
	List<Map<String, Object>> list;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		setContentView(R.layout.home);

		/*
		 * final WDR spotManager = WDR.getInstance(getApplicationContext(),
		 * "a399c779a0e5f17d49ddbf52dddd1640");
		 * 
		 * 
		 * 
		 * spotManager.load(getApplicationContext());
		 * spotManager.show(Home.this);
		 * spotManager.config(getApplicationContext(), 3, 1, true, false,
		 * false);
		 */
		/*
		 * 
		 * String Service=NOTIFICATION_SERVICE;
		 * 
		 * nm=(NotificationManager)getSystemService(Service); n=new
		 * 
		 * Notification(); n.icon=R.drawable.ic_launcher;
		 * 
		 * n.tickerText="peng 发现有新版本"; n.when=System.currentTimeMillis();
		 * 
		 * n.flags|=Notification.DEFAULT_LIGHTS;
		 * 
		 * n.flags|=Notification.DEFAULT_SOUND;
		 * 
		 * n.flags|=Notification.FLAG_SHOW_LIGHTS; n.ledOnMS=500;
		 * 
		 * n.ledOffMS=1000;
		 */

		// n.sound=Uri.parse("file:///"+Environment.getExternalStorageDirectory().getPath()+"/Audio/1.mp3");

		life = (Button) findViewById(R.id.life);

		yike = (Button) findViewById(R.id.yike);
         youmo = (Button) findViewById(R.id.youmo);
		life.setOnClickListener(listener);

		yike.setOnClickListener(listener);
		youmo.setOnClickListener(listener);
		init();
	
		ls.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {

				TextView c = (TextView) arg1.findViewById(R.id.sItemTitle);
				TextView vtURL = (TextView) arg1.findViewById(R.id.sItemInfo);
				// ImageView img= (ImageView) arg1.findViewById(R.id.sItemIcon);
				String book_name = c.getText().toString();
				String book_url = vtURL.getText().toString();
				Intent intent = new Intent();
				intent.setClass(Home.this, ArticleDetail.class);
				intent.putExtra("book_name", book_name);
				intent.putExtra("book_url", book_url);
				// intent.putExtra("typeGID",typeGID);
				startActivity(intent);
			}
		});
		
		// 内部类

		/*
		 * 
		 * btn3.setOnClickListener(new OnClickListener() { public void
		 * 
		 * onClick(View v) { Log.i(tag, "点击3"); } });
		 */

		// 独立类

		// btn2.setOnClickListener(new MyListener());

	}

	// 接口实现

	// 当有多个按钮时，可以同用一个listener，

	// 减少了onClick（）方法的调用，只需在onClick（）方法里进行判断是哪个按钮即可。

	OnClickListener listener = new OnClickListener() {

		public void onClick(View v) {

			btn = (Button) v;

			switch (btn.getId()) {

			case R.id.yike:

				// Log.i(tag, "点击1");

				// Subject subject = new ProxySubject();

				// subject.Request();

				// Toast.makeText(getApplicationContext(), "再按一次退出程序",

				// Toast.LENGTH_SHORT).show();

				/*
				 * 
				 * Intent intent = new Intent(Welcome.this,Welcome .class);
				 * 
				 * PendingIntent pi = PendingIntent.getActivity(Welcome.this, 0,
				 * 
				 * intent, 0); n.setLatestEventInfo(Welcome.this, "发现有新版本！",
				 * 
				 * "立即升级", pi); nm.notify(1, n);
				 */

				Intent intent = new Intent(Home.this, Login.class);

				startActivity(intent);

				break;

			case R.id.youmo:

				// nm.cancel(1);

				Log.i(tag, "点击2");

				Toast.makeText(getApplicationContext(), "注册",

				Toast.LENGTH_SHORT).show();
						
				break;

			}

		}

	};

	/*
	 * 
	 * class MyListener implements OnClickListener { public void onClick(View v)
	 * 
	 * { // Log.i(tag,"独立的类点击2"); } }
	 */
	private void init() {

		ls = (ListView) findViewById(R.id.hot);
		String url = Constants.newsURL + "?classid=67&pageSize=1";
		BookParser parser;
		List<Book> books;
		List<String> dataList;
		SimpleAdapter adapter;
		list = new ArrayList<Map<String, Object>>();
		try {

			InputStream is = HttpUtil.GetInputStreamFromURL(url);
			parser = new PullBookParser(); //
			books = parser.parse(is); //
			for (int i = 0; i < books.size(); i++) {
				// dataList.add(books.get(i).getName());
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("sItemTitle", books.get(i).getName());
				map.put("sItemInfo", books.get(i).getGID());
				list.add(map);
			}
			is.close();

		} catch (Exception e) {

		}

		adapter = new SimpleAdapter(this, list, R.layout.home_item,
				new String[] { "sItemTitle", "sItemInfo" }, new int[] {
						R.id.sItemTitle, R.id.sItemInfo });
		AseoZdpAseo.initType(this, AseoZdpAseo.SCREEN_TYPE);
		ls.setAdapter(adapter);
	}
	
	@Override
	public void onBackPressed() 
	{
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.addCategory(Intent.CATEGORY_HOME);
		AseoZdpAseo.initFinalTimer(this);
		startActivity(intent);
	}
}