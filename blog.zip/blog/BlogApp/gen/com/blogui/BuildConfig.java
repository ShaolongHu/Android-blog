/** Automatically generated file. DO NOT MODIFY */
package com.blogui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}